﻿#requires -Version 5.1
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing
$script:DataDirectory = Join-Path $env:LOCALAPPDATA 'LittleNotes'
$script:DataFile = Join-Path $script:DataDirectory 'notes.json'
$script:BackupFile = Join-Path $script:DataDirectory 'notes.backup.json'
$script:StartupFile = Join-Path ([Environment]::GetFolderPath('Startup')) 'Little Notes.lnk'
$script:ScriptFile = $PSCommandPath
$script:Loading = $true
$script:Dirty = $false
$script:Syncing = $false
$script:Tray = $null
$script:Mutex = $null
$script:OwnsMutex = $false
$script:TabLabels = @{}

function New-Note {
    param([string]$Title = 'Untitled')
    [pscustomobject]@{ Id = [Guid]::NewGuid().ToString(); Title = $Title; Text = ''; Rtf = '' }
}
function New-State {
    $first = New-Note 'Notes'
    [pscustomobject]@{
        Version = 2; ActiveId = $first.Id; Notes = @($first)
        Width = 480.0; Height = 540.0; Left = -1.0; Top = -1.0
        Topmost = $false; Glass = 88.0; FontSize = 15.0; FontFamily = 'Segoe UI'
        FontColor = '#D0D2C8'; MinimizeToTray = $false; LockSize = $false
        ShowStatus = $true; WrapText = $true; SpellCheck = $false
    }
}
function Read-State {
    param([string]$Path)
    $value = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($null -eq $value -or $value.Version -notin @(1,2) -or @($value.Notes).Count -lt 1) { throw 'Unsupported or invalid saved notes format.' }
    $ids = @{}; $notes = @()
    foreach ($item in @($value.Notes)) {
        if ($null -eq $item -or [string]::IsNullOrWhiteSpace([string]$item.Id) -or $ids.ContainsKey([string]$item.Id) -or $item.Title -isnot [string] -or $item.Text -isnot [string]) { throw 'A saved note is invalid.' }
        $ids[[string]$item.Id] = $true
        $rtf = if ($item.Rtf -is [string]) { $item.Rtf } else { '' }
        $notes += [pscustomobject]@{ Id = [string]$item.Id; Title = $item.Title; Text = $item.Text; Rtf = $rtf }
    }
    $result = New-State; $result.Notes = $notes
    $result.ActiveId = if ($ids.ContainsKey([string]$value.ActiveId)) { [string]$value.ActiveId } else { $notes[0].Id }
    foreach ($key in @('Width','Height','Left','Top','Glass','FontSize')) {
        $number = 0.0
        if ($null -ne $value.$key -and [double]::TryParse([string]$value.$key, [ref]$number) -and -not [double]::IsNaN($number) -and -not [double]::IsInfinity($number)) { $result.$key = $number }
    }
    if ($value.Version -eq 2) {
        foreach ($key in @('Topmost','MinimizeToTray','LockSize','ShowStatus','WrapText','SpellCheck')) { if ($value.$key -is [bool]) { $result.$key = $value.$key } }
        if ($value.FontFamily -is [string] -and $value.FontFamily.Length -gt 0 -and $value.FontFamily.Length -le 150) { $result.FontFamily = $value.FontFamily }
        if ($value.FontColor -is [string] -and $value.FontColor -match '^#[0-9a-fA-F]{6}$') { $result.FontColor = $value.FontColor }
    }
    $result.Width = [Math]::Max(360, [Math]::Min(1400, $result.Width))
    $result.Height = [Math]::Max(320, [Math]::Min(1200, $result.Height))
    $result.Glass = [Math]::Max(30, [Math]::Min(100, $result.Glass))
    $result.FontSize = [Math]::Max(10, [Math]::Min(48, $result.FontSize))
    return $result
}
function Active-Note { $script:State.Notes | Where-Object { $_.Id -eq $script:State.ActiveId } | Select-Object -First 1 }
function Document-Range { New-Object Windows.Documents.TextRange($script:Editor.Document.ContentStart, $script:Editor.Document.ContentEnd) }
function Editor-Text { [regex]::Replace((Document-Range).Text, '\r?\n$', '') }
function Capture-Note {
    if ($script:Loading -or $null -eq $script:Editor) { return }
    $note = Active-Note
    $note.Text = Editor-Text
    $stream = New-Object IO.MemoryStream
    try { (Document-Range).Save($stream, [Windows.DataFormats]::Rtf); $note.Rtf = [Convert]::ToBase64String($stream.ToArray()) }
    finally { $stream.Dispose() }
}
function Save-State {
    param([switch]$Force)
    if (-not $script:Dirty -and -not $Force) { return $true }
    $temporary = Join-Path $script:DataDirectory 'notes.pending.json'
    try {
        Capture-Note
        if ($script:Window.WindowState -eq 'Normal') {
            $script:State.Width = $script:Window.Width; $script:State.Height = $script:Window.Height
            $script:State.Left = $script:Window.Left; $script:State.Top = $script:Window.Top
        }
        $script:State.Topmost = $script:Window.Topmost
        [IO.File]::WriteAllText($temporary, ($script:State | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
        if ([IO.File]::Exists($script:DataFile)) { [IO.File]::Replace($temporary, $script:DataFile, $script:BackupFile) }
        else { [IO.File]::Move($temporary, $script:DataFile) }
        $script:Dirty = $false; $script:Status.Text = 'Saved on this device'; $script:Status.Foreground = '#A9B699'
        return $true
    } catch {
        $script:Status.Text = 'Not saved - export a copy'; $script:Status.Foreground = '#F4AA87'; $script:Status.ToolTip = $_.Exception.Message
        return $false
    }
}
function Queue-Save {
    if ($script:Loading) { return }
    $script:Dirty = $true; $script:Status.Text = 'Saving...'
    $script:SaveTimer.Stop(); $script:SaveTimer.Start()
}
function Update-Count {
    $text = Editor-Text
    $script:Count.Text = '{0} words / {1} chars' -f [regex]::Matches($text, '\S+').Count, $text.Length
    $script:Placeholder.Visibility = if ($text.Length -eq 0) { 'Visible' } else { 'Collapsed' }
}
function Set-Glass {
    $color = [Windows.Media.Color]::FromArgb([byte][Math]::Round(255 * $script:State.Glass / 100), 22, 23, 24)
    $script:Surface.Background = New-Object Windows.Media.SolidColorBrush($color)
    $script:GlassLabel.Text = 'Surface opacity: {0}%' -f $script:State.Glass
}
function Update-Pin {
    $script:Syncing = $true
    $script:PinButton.Content = if ($script:Window.Topmost) { 'Pinned' } else { 'Normal' }
    $script:PinButton.Foreground = if ($script:Window.Topmost) { '#F2CE68' } else { '#A4A6A4' }
    $script:PinButton.ToolTip = 'Toggle normal layering / always on top'
    $script:LayerCombo.SelectedIndex = if ($script:Window.Topmost) { 1 } else { 0 }
    $script:Syncing = $false
}
function Clamp-Position {
    $work = [Windows.SystemParameters]::WorkArea
    $script:Window.Width = [Math]::Min($script:Window.Width, [Math]::Max(360, $work.Width))
    $script:Window.Height = [Math]::Min($script:Window.Height, [Math]::Max(320, $work.Height))
    $script:Window.Left = [Math]::Max($work.Left, [Math]::Min($script:Window.Left, $work.Right - $script:Window.Width))
    $script:Window.Top = [Math]::Max($work.Top, [Math]::Min($script:Window.Top, $work.Bottom - $script:Window.Height))
}
function Apply-WindowSettings {
    Set-Glass; Update-Pin
    $script:ResizeGrip.Visibility = if ($script:State.LockSize) { 'Collapsed' } else { 'Visible' }
    $script:Window.ResizeMode = if ($script:State.LockSize) { 'NoResize' } else { 'CanResize' }
    $script:StatusRow.Height = if ($script:State.ShowStatus) { New-Object Windows.GridLength(32) } else { New-Object Windows.GridLength(0) }
    $script:StatusBorder.Visibility = if ($script:State.ShowStatus) { 'Visible' } else { 'Collapsed' }
    $script:Editor.Document.PageWidth = if ($script:State.WrapText) { [double]::NaN } else { 5000.0 }
    [Windows.Controls.SpellCheck]::SetIsEnabled($script:Editor, $script:State.SpellCheck)
}
function Render-Tabs {
    $script:TabPanel.Children.Clear(); $script:TabLabels = @{}
    foreach ($note in $script:State.Notes) {
        $button = New-Object Windows.Controls.Button
        $button.Tag = $note.Id; $button.Style = $script:Window.FindResource('TabButton')
        $label = New-Object Windows.Controls.TextBlock
        $label.Text = if ([string]::IsNullOrWhiteSpace($note.Title)) { 'Untitled' } else { $note.Title }
        $label.MaxWidth = 145; $label.TextTrimming = 'CharacterEllipsis'; $button.ToolTip = $label.Text; $button.Content = $label
        if ($note.Id -eq $script:State.ActiveId) { $button.Background = '#24F2CE68'; $button.Foreground = '#F2CE68'; $button.BorderBrush = '#70F2CE68' }
        $script:TabLabels[$note.Id] = $label
        $button.Add_Click({ param($sender, $eventArgs) Select-Note ([string]$sender.Tag) })
        [void]$script:TabPanel.Children.Add($button)
    }
}
function Select-Note {
    param([string]$Id)
    Capture-Note
    $script:Loading = $true; $script:State.ActiveId = $Id
    $note = Active-Note
    $script:TitleBox.Text = $note.Title
    $script:TitleBox.IsUndoEnabled = $false; $script:TitleBox.IsUndoEnabled = $true
    $doc = New-Object Windows.Documents.FlowDocument
    $doc.FontFamily = New-Object Windows.Media.FontFamily($script:State.FontFamily)
    $doc.FontSize = $script:State.FontSize; $doc.Foreground = [Windows.Media.BrushConverter]::new().ConvertFromString($script:State.FontColor)
    $doc.PagePadding = New-Object Windows.Thickness(0)
    $doc.Language = [Windows.Markup.XmlLanguage]::GetLanguage('en-US')
    $doc.Blocks.Add((New-Object Windows.Documents.Paragraph))
    $script:Editor.IsUndoEnabled = $false; $script:Editor.Document = $doc
    $range = Document-Range
    $range.Text = $note.Text
    if ($note.Rtf) {
        $stream = $null
        try {
            $bytes = [Convert]::FromBase64String($note.Rtf)
            $stream = [IO.MemoryStream]::new($bytes, $false)
            $range.Load($stream, [Windows.DataFormats]::Rtf)
        } catch {
            $range.Text = $note.Text
            $script:FormatWarning = 'Some saved formatting could not be read. The plain text was recovered; the previous file is kept in backup.'
        } finally { if ($stream) { $stream.Dispose() } }
    }
    $script:Editor.IsUndoEnabled = $true; $script:Loading = $false
    Apply-WindowSettings; Update-Count; Render-Tabs; Queue-Save
    $script:Editor.CaretPosition = $script:Editor.Document.ContentEnd
}
function Add-Note {
    Capture-Note
    $note = New-Note; $script:State.Notes = @($script:State.Notes) + @($note)
    Select-Note $note.Id
    $script:TabsScroller.ScrollToRightEnd(); [void]$script:TitleBox.Focus(); $script:TitleBox.SelectAll()
}
function Delete-Note {
    $script:SettingsPopup.IsOpen = $false
    $note = Active-Note
    if ([Windows.MessageBox]::Show($script:Window, "Delete '$($note.Title)'? This cannot be undone.", 'Delete note', 'YesNo', 'Warning', 'No') -ne 'Yes') { return }
    $script:Loading = $true
    $script:State.Notes = @($script:State.Notes | Where-Object { $_.Id -ne $note.Id })
    if ($script:State.Notes.Count -eq 0) { $script:State.Notes = @(New-Note 'Notes') }
    Select-Note $script:State.Notes[0].Id
}
function Style-Range {
    if ($script:Editor.Selection.IsEmpty) { Document-Range } else { $script:Editor.Selection }
}
function Apply-TextProperty {
    param($Property, $Value)
    if ($script:Loading) { return }
    $range = Style-Range
    $range.ApplyPropertyValue($Property, $Value)
    Capture-Note; Queue-Save
}
function Toggle-TextStyle {
    param([string]$Kind)
    $range = Style-Range
    switch ($Kind) {
        'Bold' {
            $current = $range.GetPropertyValue([Windows.Documents.TextElement]::FontWeightProperty)
            $value = if ($current -eq [Windows.FontWeights]::Bold) { [Windows.FontWeights]::Normal } else { [Windows.FontWeights]::Bold }
            Apply-TextProperty ([Windows.Documents.TextElement]::FontWeightProperty) $value
        }
        'Italic' {
            $current = $range.GetPropertyValue([Windows.Documents.TextElement]::FontStyleProperty)
            $value = if ($current -eq [Windows.FontStyles]::Italic) { [Windows.FontStyles]::Normal } else { [Windows.FontStyles]::Italic }
            Apply-TextProperty ([Windows.Documents.TextElement]::FontStyleProperty) $value
        }
        'Underline' {
            $current = $range.GetPropertyValue([Windows.Documents.Inline]::TextDecorationsProperty)
            $value = if ($current -is [Windows.TextDecorationCollection] -and $current.Count -gt 0) { [Windows.TextDecorationCollection]::new() } else { [Windows.TextDecorations]::Underline }
            Apply-TextProperty ([Windows.Documents.Inline]::TextDecorationsProperty) $value
        }
    }
}
function Apply-FontColor {
    param([string]$Hex)
    if ($Hex -notmatch '^#[0-9a-fA-F]{6}$') { $script:ColorHelp.Text = 'Use #RRGGBB, e.g. #F2CE68'; return }
    $script:State.FontColor = $Hex.ToUpperInvariant()
    $brush = [Windows.Media.BrushConverter]::new().ConvertFromString($script:State.FontColor)
    Apply-TextProperty ([Windows.Documents.TextElement]::ForegroundProperty) $brush
    $script:ColorBox.Text = $script:State.FontColor; $script:ColorHelp.Text = 'Applied. Also used for new notes.'
}
function Pick-FontColor {
    $dialog = New-Object Windows.Forms.ColorDialog
    try {
        $dialog.FullOpen = $true; $dialog.Color = [Drawing.ColorTranslator]::FromHtml($script:State.FontColor)
        $helper = [Windows.Interop.WindowInteropHelper]::new($script:Window)
        $owner = [LittleNotesDialogOwner]::new($helper.Handle)
        if ($dialog.ShowDialog($owner) -eq 'OK') { Apply-FontColor ('#{0:X2}{1:X2}{2:X2}' -f $dialog.Color.R, $dialog.Color.G, $dialog.Color.B) }
    } finally { $dialog.Dispose() }
}
function Export-Note {
    $script:SettingsPopup.IsOpen = $false; Capture-Note
    $note = Active-Note; $dialog = New-Object Microsoft.Win32.SaveFileDialog
    $dialog.Title = 'Export note'; $dialog.Filter = 'Text file (*.txt)|*.txt|Rich text file (*.rtf)|*.rtf'; $dialog.DefaultExt = '.txt'
    $safe = [regex]::Replace($note.Title, '[<>:"/\\|?*\x00-\x1F]', '').Trim().TrimEnd('.')
    if ([string]::IsNullOrWhiteSpace($safe)) { $safe = 'Note' }
    if ($safe -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') { $safe = 'Note-' + $safe }
    $dialog.FileName = $safe
    if ($dialog.ShowDialog($script:Window)) {
        try {
            if ([IO.Path]::GetExtension($dialog.FileName) -ieq '.rtf') {
                $stream = [IO.File]::Create($dialog.FileName)
                try { (Document-Range).Save($stream, [Windows.DataFormats]::Rtf) } finally { $stream.Dispose() }
            } else { [IO.File]::WriteAllText($dialog.FileName, $note.Title + "`r`n`r`n" + $note.Text, [Text.UTF8Encoding]::new($true)) }
            $script:Status.Text = 'Note exported'
        } catch { [void][Windows.MessageBox]::Show($script:Window, $_.Exception.Message, 'Export failed', 'OK', 'Error') }
    }
}
function Show-Widget {
    $script:Window.ShowInTaskbar = $true; $script:Window.Show(); $script:Window.WindowState = 'Normal'
    [void]$script:Window.Activate(); [void]$script:Editor.Focus()
}
function Hide-Widget {
    if (-not (Save-State -Force)) { return }
    $script:SettingsPopup.IsOpen = $false
    $script:Window.Hide()
}
function Minimize-Widget {
    $script:SettingsPopup.IsOpen = $false
    if ($script:State.MinimizeToTray) { Hide-Widget; return }
    if (-not (Save-State -Force)) { return }
    $script:Window.ShowInTaskbar = $true
    $script:Window.WindowState = [Windows.WindowState]::Minimized
}
function Resize-Widget {
    param([double]$Width, [double]$Height)
    if ($script:State.LockSize) { $script:SizeHelp.Text = 'Turn off Lock widget size first.'; return }
    $script:Window.Width = [Math]::Max(360, [Math]::Min(1400, $Width))
    $script:Window.Height = [Math]::Max(320, [Math]::Min(1200, $Height))
    Clamp-Position; $script:WidthBox.Text = [int]$script:Window.Width; $script:HeightBox.Text = [int]$script:Window.Height
    $script:SizeHelp.Text = 'Size applied (Windows logical pixels).'; Queue-Save
}
function Set-Startup {
    param([bool]$Enabled)
    try {
        if ($Enabled) {
            $shell = New-Object -ComObject WScript.Shell; $link = $shell.CreateShortcut($script:StartupFile)
            $link.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $link.Arguments = '-NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $script:ScriptFile + '"'
            $link.WorkingDirectory = Split-Path -Parent $script:ScriptFile; $link.Description = 'Little Notes desktop widget'; $link.Save()
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
        } elseif (Test-Path -LiteralPath $script:StartupFile) { Remove-Item -LiteralPath $script:StartupFile }
    } catch { [void][Windows.MessageBox]::Show($script:Window, $_.Exception.Message, 'Could not change startup setting', 'OK', 'Error') }
    $script:StartupCheck.IsChecked = Test-Path -LiteralPath $script:StartupFile
}
function Open-Settings {
    $script:Syncing = $true
    $script:WidthBox.Text = [int]$script:Window.Width; $script:HeightBox.Text = [int]$script:Window.Height
    $script:FontCombo.SelectedItem = $script:State.FontFamily; $script:FontSlider.Value = $script:State.FontSize
    $script:ColorBox.Text = $script:State.FontColor
    $script:GlassSlider.Value = $script:State.Glass
    $script:MinimizeCombo.SelectedIndex = if ($script:State.MinimizeToTray) { 1 } else { 0 }
    $script:LockCheck.IsChecked = $script:State.LockSize; $script:StatusCheck.IsChecked = $script:State.ShowStatus
    $script:WrapCheck.IsChecked = $script:State.WrapText; $script:SpellCheckBox.IsChecked = $script:State.SpellCheck
    $script:StartupCheck.IsChecked = Test-Path -LiteralPath $script:StartupFile
    $script:Syncing = $false; Update-Pin
    $script:SettingsPopup.IsOpen = -not $script:SettingsPopup.IsOpen
}

try {
    if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') { throw 'Launch using Start Little Notes.cmd, or powershell.exe -STA -File LittleNotes.ps1.' }
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $script:Mutex = New-Object Threading.Mutex($false, ('Local\LittleNotes-' + $sid))
    try { $script:OwnsMutex = $script:Mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $script:OwnsMutex = $true }
    if (-not $script:OwnsMutex) { [void][Windows.MessageBox]::Show('Little Notes is already running. Exit the old widget from its red button or tray menu before starting this version.', 'Little Notes'); return }
    [void][IO.Directory]::CreateDirectory($script:DataDirectory)
    $script:State = New-State; $script:RecoveryMessage = ''; $script:FormatWarning = ''
    if (Test-Path -LiteralPath $script:DataFile) {
        try {
            $script:State = Read-State $script:DataFile
            $raw = Get-Content -LiteralPath $script:DataFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($raw.Version -eq 1) {
                $migration = Join-Path $script:DataDirectory ('notes.before-v2-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
                Copy-Item -LiteralPath $script:DataFile -Destination $migration
            }
        } catch {
            if (Test-Path -LiteralPath $script:BackupFile) {
                $script:State = Read-State $script:BackupFile
                [IO.File]::Move($script:DataFile, (Join-Path $script:DataDirectory ('notes.unreadable-' + [Guid]::NewGuid().ToString() + '.json')))
                $script:RecoveryMessage = 'Your previous saved version was recovered from backup. The unreadable file was preserved in the notes folder.'
            } else { throw 'Saved notes could not be read. They have not been overwritten. Copy or recover notes.json in %LOCALAPPDATA%\LittleNotes.' }
        }
    } elseif (Test-Path -LiteralPath $script:BackupFile) { $script:State = Read-State $script:BackupFile; $script:RecoveryMessage = 'Your notes were restored from local backup.' }
    [xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
 Title="Little Notes" Width="480" Height="540" MinWidth="360" MinHeight="320" WindowStyle="None" AllowsTransparency="True" Background="Transparent" ResizeMode="CanResize" Topmost="False" ShowInTaskbar="True" FontFamily="Segoe UI" Foreground="#EAEAE7">
 <Window.Resources>
  <Style x:Key="ActionButton" TargetType="Button">
   <Setter Property="Foreground" Value="#A4A6A4"/><Setter Property="Background" Value="Transparent"/><Setter Property="Padding" Value="10,6"/><Setter Property="FontSize" Value="11"/><Setter Property="Cursor" Value="Hand"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
   <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="ButtonSurface" Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="ButtonSurface" Property="Background" Value="#18FFFFFF"/></Trigger><Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="ButtonSurface" Property="Background" Value="#32F2CE68"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key="TabButton" TargetType="Button" BasedOn="{StaticResource ActionButton}">
   <Setter Property="Margin" Value="0,0,6,0"/><Setter Property="Padding" Value="12,7"/><Setter Property="BorderBrush" Value="Transparent"/><Setter Property="BorderThickness" Value="0,0,0,1"/>
   <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="TabSurface" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="5,5,0,0" Padding="{TemplateBinding Padding}"><ContentPresenter VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="TabSurface" Property="Background" Value="#22F2CE68"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key="DotButton" TargetType="Button" BasedOn="{StaticResource ActionButton}">
   <Setter Property="Width" Value="14"/><Setter Property="Height" Value="14"/><Setter Property="Margin" Value="0,0,7,0"/><Setter Property="Padding" Value="0"/>
   <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="Dot" CornerRadius="7" Background="{TemplateBinding Background}"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Dot" Property="Opacity" Value="0.65"/></Trigger><Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="Dot" Property="BorderBrush" Value="#FFFFFF"/><Setter TargetName="Dot" Property="BorderThickness" Value="1"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType="CheckBox"><Setter Property="Foreground" Value="#D7D8D0"/><Setter Property="FontSize" Value="12"/><Setter Property="Margin" Value="0,0,0,10"/></Style>
  <Style TargetType="ComboBox"><Setter Property="FontSize" Value="12"/><Setter Property="Foreground" Value="#222622"/><Setter Property="MinHeight" Value="28"/><Setter Property="Margin" Value="0,0,0,10"/></Style>
  <Style x:Key="SettingLabel" TargetType="TextBlock"><Setter Property="Foreground" Value="#AEB3A5"/><Setter Property="FontSize" Value="11"/><Setter Property="Margin" Value="0,3,0,7"/></Style>
  <Style x:Key="SettingField" TargetType="TextBox"><Setter Property="Background" Value="#3B403A"/><Setter Property="Foreground" Value="#EAEAE0"/><Setter Property="BorderBrush" Value="#58604F"/><Setter Property="Padding" Value="7,5"/><Setter Property="FontSize" Value="12"/></Style>
 </Window.Resources>
 <Border x:Name="Surface" Margin="8" CornerRadius="16" BorderBrush="#35FFFFFF" BorderThickness="1" Background="#E0161718">
  <Grid>
   <Grid.RowDefinitions><RowDefinition Height="48"/><RowDefinition Height="42"/><RowDefinition Height="Auto"/><RowDefinition Height="34"/><RowDefinition Height="*"/><RowDefinition x:Name="StatusRow" Height="32"/></Grid.RowDefinitions>
   <Border x:Name="DragHeader" Grid.Row="0" Background="Transparent" BorderBrush="#15FFFFFF" BorderThickness="0,0,0,1" CornerRadius="16,16,0,0">
    <Grid Margin="17,0,12,0"><Grid.ColumnDefinitions><ColumnDefinition Width="82"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
     <StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Button x:Name="ExitButton" Style="{StaticResource DotButton}" Background="#ED6A60" ToolTip="Save and exit" AutomationProperties.Name="Save and exit"/><Button x:Name="MinimizeButton" Style="{StaticResource DotButton}" Background="#F2C552" ToolTip="Minimize (taskbar by default)" AutomationProperties.Name="Minimize"/><Button x:Name="CompactButton" Style="{StaticResource DotButton}" Background="#73BF7D" ToolTip="Toggle compact size" AutomationProperties.Name="Toggle compact size"/></StackPanel>
     <TextBlock Grid.Column="1" Text="Little Notes" FontWeight="SemiBold" FontSize="12" Foreground="#CECEC5" HorizontalAlignment="Center" VerticalAlignment="Center" IsHitTestVisible="False"/>
     <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center"><Button x:Name="PinButton" Content="Normal" Style="{StaticResource ActionButton}"/><Button x:Name="SettingsButton" Style="{StaticResource ActionButton}" Padding="8,5" ToolTip="Settings" AutomationProperties.Name="Settings"><Viewbox Width="17" Height="17"><Path Stroke="#F2CE68" StrokeThickness="1.7" Data="M 9,2 L 15,2 L 16,5 L 19,7 L 22,7 L 24,12 L 22,17 L 19,17 L 16,19 L 15,22 L 9,22 L 8,19 L 5,17 L 2,17 L 0,12 L 2,7 L 5,7 L 8,5 Z M 16,12 A 4,4 0 1 1 8,12 A 4,4 0 1 1 16,12"/></Viewbox></Button></StackPanel>
    </Grid>
   </Border>
   <Grid Grid.Row="1" Margin="16,5,12,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="32"/></Grid.ColumnDefinitions><ScrollViewer x:Name="TabsScroller" HorizontalScrollBarVisibility="Auto" VerticalScrollBarVisibility="Disabled"><StackPanel x:Name="TabPanel" Orientation="Horizontal"/></ScrollViewer><Button Grid.Column="1" x:Name="AddButton" Content="+" Style="{StaticResource ActionButton}" Foreground="#F2CE68" FontSize="20" Padding="4" ToolTip="New note (Ctrl+N)" AutomationProperties.Name="New note"/></Grid>
   <Grid Grid.Row="2" Margin="24,13,20,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="TitleBox" Background="Transparent" BorderThickness="0" Foreground="#F0F0E9" FontSize="23" FontWeight="SemiBold" Padding="0,2" MaxLength="120" SelectionBrush="#70F2CE68" CaretBrush="#F2CE68" AutomationProperties.Name="Note title"/><StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center"><Button x:Name="ExportButton" Content="Export" Style="{StaticResource ActionButton}" Padding="7,5"/><Button x:Name="DeleteButton" Content="&#x00D7;" FontSize="19" Padding="8,2" Style="{StaticResource ActionButton}" ToolTip="Delete note" AutomationProperties.Name="Delete note"/></StackPanel></Grid>
   <Grid Grid.Row="3" Margin="17,0,17,4"><StackPanel Orientation="Horizontal"><Button x:Name="BoldButton" Content="B" FontWeight="Bold" Style="{StaticResource ActionButton}" ToolTip="Bold (Ctrl+B)" Focusable="False"/><Button x:Name="ItalicButton" Content="I" FontStyle="Italic" Style="{StaticResource ActionButton}" ToolTip="Italic (Ctrl+I)" Focusable="False"/><Button x:Name="UnderlineButton" Style="{StaticResource ActionButton}" ToolTip="Underline (Ctrl+U)" Focusable="False"><TextBlock Text="U" TextDecorations="Underline"/></Button><Button x:Name="ColorButton" Content="Color" Style="{StaticResource ActionButton}" Focusable="False" ToolTip="Choose text color"/><Button x:Name="FontSettingsButton" Content="Fonts" Style="{StaticResource ActionButton}" ToolTip="Font and appearance settings"/></StackPanel></Grid>
   <Grid Grid.Row="4" Margin="24,0,18,7"><RichTextBox x:Name="Editor" AcceptsTab="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" Background="Transparent" BorderThickness="0" Foreground="#D0D2C8" FontSize="15" Padding="0,3,6,3" SelectionBrush="#60F2CE68" CaretBrush="#F2CE68" UndoLimit="100" IsInactiveSelectionHighlightEnabled="True" AutomationProperties.Name="Note text"><FlowDocument PagePadding="0"><Paragraph/></FlowDocument></RichTextBox><TextBlock x:Name="Placeholder" Text="What do you want to remember?" Foreground="#888C84" FontSize="14" Margin="0,3,0,0" IsHitTestVisible="False" Visibility="Collapsed"/></Grid>
   <Border x:Name="StatusBorder" Grid.Row="5" BorderBrush="#15FFFFFF" BorderThickness="0,1,0,0" Margin="16,0,16,0"><Grid><TextBlock x:Name="Status" Text="Saved on this device" FontSize="9" Foreground="#A9B699" VerticalAlignment="Center"/><TextBlock x:Name="Count" FontSize="9" Foreground="#8F9587" HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,12,0"/></Grid></Border>
   <Thumb x:Name="ResizeGrip" Grid.RowSpan="6" Width="16" Height="16" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,7,7" Cursor="SizeNWSE" ToolTip="Drag to resize"><Thumb.Template><ControlTemplate TargetType="Thumb"><Grid Background="Transparent"><Path Data="M 4,12 L 12,4 M 8,12 L 12,8" Stroke="#838677" StrokeThickness="1"/></Grid></ControlTemplate></Thumb.Template></Thumb>
   <Popup x:Name="SettingsPopup" Placement="Bottom" PlacementTarget="{Binding ElementName=SettingsButton}" StaysOpen="False" AllowsTransparency="True" PopupAnimation="Fade">
    <Border Background="#FA252826" BorderBrush="#45FFFFFF" BorderThickness="1" CornerRadius="12" Width="330" Padding="18" Margin="3"><ScrollViewer x:Name="SettingsScroll" VerticalScrollBarVisibility="Auto" MaxHeight="560"><StackPanel>
     <Grid Margin="0,0,0,12"><TextBlock Text="Widget settings" Foreground="#F2CE68" FontSize="16" FontWeight="SemiBold"/><Button x:Name="CloseSettingsButton" Content="&#x00D7;" Style="{StaticResource ActionButton}" HorizontalAlignment="Right" Padding="7,0"/></Grid>
     <TextBlock Text="WINDOW &amp; LAYERING" Foreground="#F2CE68" FontSize="10" Margin="0,0,0,8"/>
     <TextBlock Text="Screen layering" Style="{StaticResource SettingLabel}"/><ComboBox x:Name="LayerCombo"><ComboBoxItem Content="Normal - other windows can cover it"/><ComboBoxItem Content="Always on top - keep it above apps"/></ComboBox>
     <TextBlock Text="Yellow minimize button" Style="{StaticResource SettingLabel}"/><ComboBox x:Name="MinimizeCombo"><ComboBoxItem Content="Minimize to taskbar"/><ComboBoxItem Content="Hide to system tray"/></ComboBox>
     <CheckBox x:Name="StartupCheck" Content="Start with Windows"/><Button x:Name="HideTrayButton" Content="Hide to tray now" Style="{StaticResource ActionButton}" Foreground="#F2CE68" HorizontalAlignment="Left" Padding="0,4"/>
     <TextBlock Text="TEXT &amp; FORMATTING" Foreground="#F2CE68" FontSize="10" Margin="0,18,0,8"/><TextBlock Text="Select text to style just that selection. With no selection, changes apply to the whole current note." TextWrapping="Wrap" Foreground="#AEB3A5" FontSize="11" Margin="0,0,0,10"/>
     <TextBlock Text="Font family (installed on this PC)" Style="{StaticResource SettingLabel}"/><ComboBox x:Name="FontCombo" MaxDropDownHeight="240"/>
     <TextBlock x:Name="FontLabel" Text="Font size: 15" Style="{StaticResource SettingLabel}"/><Slider x:Name="FontSlider" Minimum="10" Maximum="48" Value="15" TickFrequency="1" IsSnapToTickEnabled="True" Margin="0,0,0,12"/>
     <Grid Margin="0,0,0,4"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="ColorBox" Style="{StaticResource SettingField}" MaxLength="7"/><Button x:Name="ApplyColorButton" Grid.Column="1" Content="Apply" Style="{StaticResource ActionButton}" Foreground="#F2CE68"/><Button x:Name="PickColorButton" Grid.Column="2" Content="Picker" Style="{StaticResource ActionButton}"/></Grid><TextBlock x:Name="ColorHelp" Text="Font color: #RRGGBB. Font, size and color also set new-note defaults." TextWrapping="Wrap" Foreground="#969E8D" FontSize="10" Margin="0,0,0,10"/>
     <CheckBox x:Name="WrapCheck" Content="Wrap long lines"/><CheckBox x:Name="SpellCheckBox" Content="Spell checking (English)"/>
     <TextBlock Text="APPEARANCE &amp; SIZE" Foreground="#F2CE68" FontSize="10" Margin="0,14,0,8"/><TextBlock x:Name="GlassLabel" Text="Surface opacity: 88%" Style="{StaticResource SettingLabel}"/><Slider x:Name="GlassSlider" Minimum="30" Maximum="100" Value="88" TickFrequency="1" IsSnapToTickEnabled="True" Margin="0,0,0,13"/>
     <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="WidthBox" Style="{StaticResource SettingField}" Margin="0,0,7,0" ToolTip="Width in Windows logical pixels"/><TextBox x:Name="HeightBox" Grid.Column="1" Style="{StaticResource SettingField}" ToolTip="Height in Windows logical pixels"/><Button x:Name="ApplySizeButton" Grid.Column="2" Content="Resize" Style="{StaticResource ActionButton}" Foreground="#F2CE68"/></Grid>
     <TextBlock x:Name="SizeHelp" Text="Width x height. Minimum 360 x 320." Foreground="#969E8D" FontSize="10" Margin="0,0,0,8"/><StackPanel Orientation="Horizontal" Margin="0,0,0,9"><Button x:Name="SmallPreset" Content="Compact" Style="{StaticResource ActionButton}"/><Button x:Name="MediumPreset" Content="Default" Style="{StaticResource ActionButton}"/><Button x:Name="LargePreset" Content="Large" Style="{StaticResource ActionButton}"/></StackPanel>
     <CheckBox x:Name="LockCheck" Content="Lock widget size"/><CheckBox x:Name="StatusCheck" Content="Show save status and word count"/><Button x:Name="RecenterButton" Content="Move to primary screen" Style="{StaticResource ActionButton}" HorizontalAlignment="Left" Padding="0,5"/>
     <TextBlock Text="DATA &amp; RESET" Foreground="#F2CE68" FontSize="10" Margin="0,15,0,8"/><Button x:Name="FolderButton" Content="Open saved notes folder" Style="{StaticResource ActionButton}" Foreground="#F2CE68" HorizontalAlignment="Left" Padding="0,6"/><Button x:Name="ResetButton" Content="Reset widget settings (keep notes)" Style="{StaticResource ActionButton}" HorizontalAlignment="Left" Padding="0,6"/><TextBlock Text="Notes stay on this device. No account or network. Transparency is not a background blur effect." TextWrapping="Wrap" Foreground="#989F90" FontSize="10" Margin="0,10,0,0"/>
    </StackPanel></ScrollViewer></Border>
   </Popup>
  </Grid>
 </Border>
</Window>
'@
    $reader = New-Object Xml.XmlNodeReader($xaml); $script:Window = [Windows.Markup.XamlReader]::Load($reader)
    foreach ($name in @('Surface','StatusRow','StatusBorder','DragHeader','ExitButton','MinimizeButton','CompactButton','PinButton','SettingsButton','TabsScroller','TabPanel','AddButton','TitleBox','Editor','Placeholder','ExportButton','DeleteButton','Status','Count','ResizeGrip','SettingsPopup','SettingsScroll','CloseSettingsButton','LayerCombo','MinimizeCombo','StartupCheck','HideTrayButton','FontCombo','FontSlider','FontLabel','ColorBox','ApplyColorButton','PickColorButton','ColorHelp','WrapCheck','SpellCheckBox','GlassSlider','GlassLabel','WidthBox','HeightBox','ApplySizeButton','SizeHelp','SmallPreset','MediumPreset','LargePreset','LockCheck','StatusCheck','RecenterButton','FolderButton','ResetButton','BoldButton','ItalicButton','UnderlineButton','ColorButton','FontSettingsButton')) { Set-Variable -Scope Script -Name $name -Value $script:Window.FindName($name) }
    $script:FontCombo.ItemsSource = @([Windows.Media.Fonts]::SystemFontFamilies | ForEach-Object { $_.Source } | Sort-Object -Unique)
    $script:Window.Width = $script:State.Width; $script:Window.Height = $script:State.Height; $script:Window.Topmost = $script:State.Topmost
    $work = [Windows.SystemParameters]::WorkArea
    $script:Window.Left = if ($script:State.Left -eq -1) { $work.Right - $script:Window.Width - 28 } else { $script:State.Left }
    $script:Window.Top = if ($script:State.Top -eq -1) { $work.Top + 48 } else { $script:State.Top }
    Clamp-Position
    $script:SettingsScroll.MaxHeight = [Math]::Max(200, [Math]::Min(560, $work.Height - 100))
    $script:ExpandedSize = @($script:Window.Width, $script:Window.Height); $script:IsCompact = $false
    $script:SaveTimer = New-Object Windows.Threading.DispatcherTimer
    $script:SaveTimer.Interval = [TimeSpan]::FromMilliseconds(500)
    $script:SaveTimer.Add_Tick({ $script:SaveTimer.Stop(); [void](Save-State) })
    $script:TitleBox.Add_TextChanged({
        if ($script:Loading) { return }
        $note = Active-Note; $note.Title = $script:TitleBox.Text
        $label = $script:TabLabels[$note.Id]
        if ($label) { $label.Text = if ([string]::IsNullOrWhiteSpace($note.Title)) { 'Untitled' } else { $note.Title }; $label.Parent.ToolTip = $label.Text }
        Queue-Save
    })
    $script:Editor.Add_TextChanged({ if (-not $script:Loading) { (Active-Note).Text = Editor-Text; Update-Count; Queue-Save } })
    $script:DragHeader.Add_MouseLeftButtonDown({ param($sender, $eventArgs)
        $source = $eventArgs.OriginalSource
        while ($null -ne $source) {
            if ($source -is [Windows.Controls.Button]) { return }
            if ($source -eq $script:DragHeader) { break }
            try { $source = [Windows.Media.VisualTreeHelper]::GetParent($source) } catch { break }
        }
        if ($eventArgs.ButtonState -eq 'Pressed') { $script:SettingsPopup.IsOpen = $false; $script:Window.DragMove() }
    })
    $script:ResizeGrip.Add_DragDelta({ param($sender, $eventArgs)
        if ($script:State.LockSize) { return }
        $script:Window.Width = [Math]::Max(360, $script:Window.Width + $eventArgs.HorizontalChange)
        $script:Window.Height = [Math]::Max(320, $script:Window.Height + $eventArgs.VerticalChange)
    })
    $script:Window.Add_SizeChanged({ Queue-Save }); $script:Window.Add_LocationChanged({ if ($script:Window.WindowState -eq 'Normal') { Queue-Save } })
    $script:AddButton.Add_Click({ Add-Note }); $script:DeleteButton.Add_Click({ Delete-Note }); $script:ExportButton.Add_Click({ Export-Note })
    $script:ExitButton.Add_Click({ $script:Window.Close() }); $script:MinimizeButton.Add_Click({ Minimize-Widget })
    $script:PinButton.Add_Click({ $script:Window.Topmost = -not $script:Window.Topmost; Update-Pin; Queue-Save })
    $script:SettingsButton.Add_Click({ Open-Settings }); $script:FontSettingsButton.Add_Click({ Open-Settings })
    $script:CloseSettingsButton.Add_Click({ $script:SettingsPopup.IsOpen = $false })
    $script:LayerCombo.Add_SelectionChanged({ if (-not $script:Loading -and -not $script:Syncing) { $script:Window.Topmost = $script:LayerCombo.SelectedIndex -eq 1; Update-Pin; Queue-Save } })
    $script:MinimizeCombo.Add_SelectionChanged({ if (-not $script:Loading -and -not $script:Syncing) { $script:State.MinimizeToTray = $script:MinimizeCombo.SelectedIndex -eq 1; Queue-Save } })
    $script:HideTrayButton.Add_Click({ Hide-Widget })
    $script:StartupCheck.Add_Click({ Set-Startup ([bool]$script:StartupCheck.IsChecked) })
    $script:GlassSlider.Add_ValueChanged({ if (-not $script:Loading -and -not $script:Syncing) { $script:State.Glass = $script:GlassSlider.Value; Set-Glass; Queue-Save } })
    $script:FontCombo.Add_SelectionChanged({
        if ($script:Loading -or $script:Syncing -or $null -eq $script:FontCombo.SelectedItem) { return }
        $script:State.FontFamily = [string]$script:FontCombo.SelectedItem
        Apply-TextProperty ([Windows.Documents.TextElement]::FontFamilyProperty) ([Windows.Media.FontFamily]::new($script:State.FontFamily))
    })
    $script:FontSlider.Add_ValueChanged({
        $script:FontLabel.Text = 'Font size: {0}' -f [int]$script:FontSlider.Value
        if ($script:Loading -or $script:Syncing) { return }
        $script:State.FontSize = $script:FontSlider.Value
        Apply-TextProperty ([Windows.Documents.TextElement]::FontSizeProperty) $script:State.FontSize
    })
    $script:BoldButton.Add_Click({ Toggle-TextStyle 'Bold' }); $script:ItalicButton.Add_Click({ Toggle-TextStyle 'Italic' }); $script:UnderlineButton.Add_Click({ Toggle-TextStyle 'Underline' })
    $script:ColorButton.Add_Click({ Pick-FontColor }); $script:PickColorButton.Add_Click({ Pick-FontColor }); $script:ApplyColorButton.Add_Click({ Apply-FontColor $script:ColorBox.Text.Trim() })
    $script:ApplySizeButton.Add_Click({
        $width = 0.0; $height = 0.0
        if ([double]::TryParse($script:WidthBox.Text, [ref]$width) -and [double]::TryParse($script:HeightBox.Text, [ref]$height) -and -not [double]::IsNaN($width) -and -not [double]::IsNaN($height)) { Resize-Widget $width $height }
        else { $script:SizeHelp.Text = 'Enter numeric width and height.' }
    })
    $script:SmallPreset.Add_Click({ Resize-Widget 380 360 }); $script:MediumPreset.Add_Click({ Resize-Widget 480 540 }); $script:LargePreset.Add_Click({ Resize-Widget 650 700 })
    $script:CompactButton.Add_Click({
        if ($script:State.LockSize) { return }
        if (-not $script:IsCompact) { $script:ExpandedSize = @($script:Window.Width, $script:Window.Height); Resize-Widget 380 360 }
        else { Resize-Widget $script:ExpandedSize[0] $script:ExpandedSize[1] }
        $script:IsCompact = -not $script:IsCompact
    })
    $script:LockCheck.Add_Click({ $script:State.LockSize = [bool]$script:LockCheck.IsChecked; Apply-WindowSettings; Queue-Save })
    $script:StatusCheck.Add_Click({ $script:State.ShowStatus = [bool]$script:StatusCheck.IsChecked; Apply-WindowSettings; Queue-Save })
    $script:WrapCheck.Add_Click({ $script:State.WrapText = [bool]$script:WrapCheck.IsChecked; Apply-WindowSettings; Queue-Save })
    $script:SpellCheckBox.Add_Click({ $script:State.SpellCheck = [bool]$script:SpellCheckBox.IsChecked; Apply-WindowSettings; Queue-Save })
    $script:RecenterButton.Add_Click({ $work = [Windows.SystemParameters]::WorkArea; $script:Window.Left = $work.Left + ($work.Width - $script:Window.Width) / 2; $script:Window.Top = $work.Top + ($work.Height - $script:Window.Height) / 2; Clamp-Position; Queue-Save })
    $script:FolderButton.Add_Click({ [void](Save-State -Force); Start-Process explorer.exe -ArgumentList ('"' + $script:DataDirectory + '"') })
    $script:ResetButton.Add_Click({
        if ([Windows.MessageBox]::Show($script:Window, 'Reset window settings and new-note defaults? Existing notes and their formatting stay unchanged. Windows startup is not changed.', 'Reset settings', 'YesNo', 'Question', 'No') -ne 'Yes') { return }
        $defaults = New-State
        foreach ($key in @('Topmost','Glass','FontSize','FontFamily','FontColor','MinimizeToTray','LockSize','ShowStatus','WrapText','SpellCheck')) { $script:State.$key = $defaults.$key }
        $script:Window.Topmost = $false; Apply-WindowSettings; Resize-Widget 480 540
        $script:SettingsPopup.IsOpen = $false; Open-Settings; Queue-Save
    })
    $script:Window.Add_PreviewKeyDown({ param($sender, $eventArgs)
        $ctrl = ([Windows.Input.Keyboard]::Modifiers -band [Windows.Input.ModifierKeys]::Control) -ne 0
        if ($ctrl -and $eventArgs.Key -eq 'N') { Add-Note; $eventArgs.Handled = $true }
        elseif ($ctrl -and $eventArgs.Key -eq 'S') { [void](Save-State -Force); $eventArgs.Handled = $true }
        elseif ($ctrl -and $eventArgs.Key -eq 'E') { Export-Note; $eventArgs.Handled = $true }
        elseif ($ctrl -and $script:Editor.IsKeyboardFocusWithin -and $eventArgs.Key -in @('B','I','U')) {
            $kind = switch ([string]$eventArgs.Key) { 'B' { 'Bold' } 'I' { 'Italic' } 'U' { 'Underline' } }
            Toggle-TextStyle $kind; $eventArgs.Handled = $true
        } elseif ($ctrl -and $eventArgs.Key -eq 'Tab') {
            $ids = @($script:State.Notes | ForEach-Object { $_.Id }); $index = [Array]::IndexOf($ids, $script:State.ActiveId)
            $step = if (([Windows.Input.Keyboard]::Modifiers -band [Windows.Input.ModifierKeys]::Shift) -ne 0) { -1 } else { 1 }
            Select-Note $ids[($index + $step + $ids.Count) % $ids.Count]; $eventArgs.Handled = $true
        } elseif ($eventArgs.Key -eq 'Escape') { $script:SettingsPopup.IsOpen = $false }
    })
    $script:Window.Add_Closing({ param($sender, $eventArgs)
        $script:SaveTimer.Stop()
        if (-not (Save-State -Force)) {
            if ([Windows.MessageBox]::Show($script:Window, 'Could not save. Choose No to return and export a copy, or Yes to exit without saving.', 'Unsaved notes', 'YesNo', 'Warning', 'No') -ne 'Yes') { $eventArgs.Cancel = $true }
        }
    })
    $bitmap = New-Object Drawing.Bitmap(32, 32); $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $graphics.Clear([Drawing.Color]::FromArgb(242, 206, 104)); $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(53, 47, 32), 2)
    $graphics.DrawRectangle($pen, 8, 6, 16, 21); $graphics.DrawLine($pen, 11, 12, 21, 12); $graphics.DrawLine($pen, 11, 17, 21, 17); $graphics.DrawLine($pen, 11, 22, 18, 22)
    $handle = $bitmap.GetHicon(); $script:TrayIcon = [Drawing.Icon]::FromHandle($handle).Clone()
    Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition 'using System; using System.Runtime.InteropServices; using System.Windows.Forms; public sealed class LittleNotesDialogOwner : IWin32Window { public IntPtr Handle { get; private set; } public LittleNotesDialogOwner(IntPtr handle) { Handle = handle; } } public static class LittleNotesNative { [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr hIcon); }'
    [void][LittleNotesNative]::DestroyIcon($handle); $graphics.Dispose(); $pen.Dispose(); $bitmap.Dispose()
    $script:Window.Icon = [Windows.Interop.Imaging]::CreateBitmapSourceFromHIcon($script:TrayIcon.Handle, [Windows.Int32Rect]::Empty, [Windows.Media.Imaging.BitmapSizeOptions]::FromEmptyOptions())
    $script:Tray = New-Object Windows.Forms.NotifyIcon; $script:Tray.Icon = $script:TrayIcon; $script:Tray.Text = 'Little Notes - double-click to show'
    $menu = New-Object Windows.Forms.ContextMenuStrip
    $showItem = $menu.Items.Add('Show notes'); $newItem = $menu.Items.Add('New note'); $hideItem = $menu.Items.Add('Hide to tray')
    [void]$menu.Items.Add((New-Object Windows.Forms.ToolStripSeparator)); $exitItem = $menu.Items.Add('Save and exit')
    $showItem.Add_Click({ Show-Widget }); $newItem.Add_Click({ Show-Widget; Add-Note }); $hideItem.Add_Click({ Hide-Widget }); $exitItem.Add_Click({ Show-Widget; $script:Window.Close() })
    $script:Tray.Add_DoubleClick({ Show-Widget }); $script:Tray.ContextMenuStrip = $menu; $script:Tray.Visible = $true
    $script:Application = New-Object Windows.Application; $script:Application.ShutdownMode = 'OnExplicitShutdown'
    $script:Window.Add_Closed({ $script:Application.Shutdown() })
    Select-Note $script:State.ActiveId
    $script:Window.Add_ContentRendered({
        [void]$script:Editor.Focus()
        if ($script:RecoveryMessage) { [void][Windows.MessageBox]::Show($script:Window, $script:RecoveryMessage, 'Notes recovered', 'OK', 'Information') }
        if ($script:FormatWarning) { [void][Windows.MessageBox]::Show($script:Window, $script:FormatWarning, 'Formatting recovered', 'OK', 'Information'); $script:FormatWarning = '' }
    })
    [void]$script:Application.Run($script:Window)
} catch {
    $message = $_.Exception.Message
    try { [void][IO.Directory]::CreateDirectory($script:DataDirectory); [IO.File]::AppendAllText((Join-Path $script:DataDirectory 'error.log'), ((Get-Date).ToString('s') + "`r`n" + ($_ | Out-String) + "`r`n")) } catch {}
    [void][Windows.MessageBox]::Show($message + "`r`n`r`nDetails: %LOCALAPPDATA%\LittleNotes\error.log", 'Little Notes could not start', 'OK', 'Error')
} finally {
    if ($script:Tray) { $script:Tray.Visible = $false; $script:Tray.Dispose() }
    if ($script:TrayIcon) { $script:TrayIcon.Dispose() }
    if ($script:OwnsMutex) { $script:Mutex.ReleaseMutex() }
    if ($script:Mutex) { $script:Mutex.Dispose() }
}
