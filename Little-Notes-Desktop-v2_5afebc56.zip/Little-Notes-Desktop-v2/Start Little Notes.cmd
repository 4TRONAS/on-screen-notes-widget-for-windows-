@echo off
setlocal
set "NOTES_SCRIPT=%~dp0LittleNotes.ps1"
if not exist "%NOTES_SCRIPT%" (
 echo LittleNotes.ps1 is missing. Extract the entire ZIP first.
 pause
 exit /b 1
)
start "" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "%NOTES_SCRIPT%"
endlocal
