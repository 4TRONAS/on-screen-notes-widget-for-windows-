LITTLE NOTES 2 - WINDOWS DESKTOP WIDGET
======================================
Windows 10/11, Windows PowerShell 5.1 and built-in .NET Framework/WPF.
No browser, additional modules, admin access or network connection required.

UPGRADE YOUR APPLE NOTES FOLDER
1. Exit the old widget using the red dot or tray > Save and exit.
2. Extract this ZIP. Replace LittleNotes.ps1 and Start Little Notes.cmd
   in your existing apple notes folder with the new files.
3. Double-click Start Little Notes.cmd, or use PowerShell:

powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File ".\LittleNotes.ps1"

Run the command from the folder containing LittleNotes.ps1. The launcher
can be double-clicked instead if you do not want a visible console.
Do not launch two versions at once: they share the same local notes folder.
The app refuses a second instance to avoid concurrent saves.

EXISTING NOTES ARE KEPT
Notes remain in %LOCALAPPDATA%\LittleNotes\notes.json. V1 notes are read and
upgraded automatically. A separate notes.before-v2-<timestamp>.json copy
is saved on the first upgrade. Keep this file if you might return to v1.
Do not run v1 against v2 notes: the data format has changed to preserve styling.
V1 always-on-top is deliberately reset to NORMAL on upgrade. In v2 your
layering preference saves normally. No romantic sample notes are included.

MINIMIZE AND LAYERING
- Yellow dot now minimizes to the taskbar by default. Click the Little Notes
  taskbar icon to restore it.
- Gear > Yellow minimize button can change that to Hide to system tray.
- Gear > Hide to tray now, or tray > Hide to tray, is a separate action.
- Double-click the tray icon to restore; check Windows hidden tray icons too.
- Normal layering is the default. Other application windows can cover it.
- Gear > Screen layering selects Normal or Always on top. The header button
  toggles the same choice and displays Normal / Pinned.
- Red dot saves and exits; green dot switches compact/expanded size.
- Tray hiding does not stop the WPF application loop or exit the app.

RICH TEXT
Use the toolbar B / I / U for bold, italic and underline. Color opens a picker.
Gear > Text & formatting contains installed fonts, size, color picker, hex
color, wrapping and English spell-check controls.
Select text first to format only that selection. If no text is selected,
formatting changes apply to the entire current note. This also works for
an empty note; the chosen style is inherited by text typed into it.
Font family, size and color choices also become the defaults for new notes.
Existing notes keep their own saved formatting until you change them.
Note titles use the UI font; text formatting applies to the note body.
Formatting is saved per note as RTF, with a plain-text copy in the JSON too.
Export supports .txt (plain text) and .rtf (preserves formatting).
Undo history is cleared when switching notes, so Ctrl+Z cannot undo text
from another note.

MORE SETTINGS
- Opacity from 30% to 100%, applied to the dark surface only. Text remains solid.
- Numeric width/height; compact, default and large presets; drag resize grip.
- Lock size disables resizing and compact toggling, but still permits moving.
- Show/hide the save status and word count.
- Move to primary screen to recover an awkward window position.
- Optional Start with Windows (off by default, per-user shortcut only).
- Open notes folder and Reset widget settings without deleting notes.
- Reset preserves existing rich-text formatting and does not change startup.
The gear panel scrolls to expose all settings on shorter screens.
Widget dimensions are Windows logical pixels (DPI-scaled), not raw pixels.

SHORTCUTS (WHILE THE WIDGET HAS FOCUS)
Ctrl+N: new note. Ctrl+Tab / Ctrl+Shift+Tab: next / previous note.
Ctrl+S: save. Ctrl+E: export. Ctrl+B / I / U: text style in the note editor.
Ctrl+Z / Ctrl+Y: undo / redo. Escape: close settings.

AUTOSAVE AND BACKUP
Autosave runs after about half a second of inactivity, and on hide/minimize/
exit. Switching tabs captures the outgoing text and formatting immediately.
notes.backup.json contains the previous successful save, not permanent history.
If the main JSON is unreadable, the backup is tried and the unreadable original
is preserved. For an independent backup, exit and copy the whole data folder.
Notes are local and unencrypted. Nothing is sent to a server.
If saving fails, the window stays visible instead of hiding/minimizing, so
you can export a copy. Inspect the status bar before exit.

STARTUP
Keep the program in a permanent folder before enabling Start with Windows.
If an old startup shortcut points at another folder, turn the checkbox off
and back on from v2 to update the path. Disable startup before uninstalling.

SECURITY / LIMITATIONS
The launcher uses ExecutionPolicy Bypass only for that process. It does not
change system policy, elevate permissions, or bypass managed-device security.
The optional startup shortcut is the only requested Windows configuration change.
Always-on-top cannot cover secure desktop prompts or guarantee precedence over
exclusive fullscreen apps. Normal layering is not wallpaper-layer embedding.
Opacity is genuine translucency, not background blur/Mica.
WPF UI and rich-text rendering require Windows. Syntax, XML and portable data
logic are checked in the Linux build environment; native UI behavior cannot be
executed there and still needs confirmation on your Windows machine.

ERRORS / UNINSTALL
Startup errors appear in a dialog; details: %LOCALAPPDATA%\LittleNotes\error.log.
Disable startup, save and exit, then delete the program folder to uninstall.
Your notes remain in %LOCALAPPDATA%\LittleNotes unless you delete them too.
